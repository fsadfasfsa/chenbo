package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Book;
import dao.BookDao;

public class updateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		//获取图书数据
		BookDao bookDao =new BookDao();
		int id =(Integer.parseInt(request.getParameter("id")));
		bookDao.getBooksByid(id);
		String novel_name=request.getParameter("novel_name");
		String author_name=request.getParameter("author_name");
		String novel_content=request.getParameter("novel_content");
		String uploaduser=request.getParameter("uploaduser");
		String createdate=request.getParameter("createdate");
		
		//把获取到的对象用Book对象存储起来
		Book b =new Book();
		b.setId(id);
		b.setNovel_name(novel_name);
		b.setAuthor_name(author_name);
		b.setNovel_content(novel_content);
		b.setUploaduser(uploaduser);
		b.setCreatedate(createdate);
		int i=bookDao.updBook(b);//添加成功返回值为1
		if(i>0){
			//提示用户更新结果
			List<Book> list=bookDao.getAllBooks();
			request.getSession().setAttribute("list", list);
			out.print("<script>alert('update succeed!!!');location.href='index.jsp';</script>");
		} else{
			out.print("<script>alert('update failed!!!');location.href='Update.jsp';</script>");
		}
		out.flush();
		out.close();
	}
}
