package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Book;
import dao.BookDao;

public class deleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request, response);
	}
 
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		BookDao bookDao =new BookDao();
		
		//Book b=new Book();
		int id=Integer.parseInt(request.getParameter("id"));
		//b.setId(id);
		int i=bookDao.delBook(id);
		if(i>0){
			List<Book> list = bookDao.getAllBooks();
			request.getSession().setAttribute("list", list);
			out.print("<script>alert('delete succeed！！！');location.href='index.jsp';</script>");
		}else{
			out.print("<script>alert('delete failed！！！');location.href='index.jsp';</script>");
		}
		
		out.flush();
		out.close();
	}
}
