package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.User;
import dao.UserDao;

public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html;charset=UTF-8");
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");
		String method = req.getParameter("dowhat");    
		UserDao userDao = new UserDao();

		//ע��
		if("register".equals(method)){
			User user = new User();
			user.setId(Integer.parseInt(req.getParameter("id")));//���ַ���ת��Ϊ����
			user.setUsername(req.getParameter("username"));
			user.setPassword(req.getParameter("password"));
			user.setEmail(req.getParameter("email"));
			user.setSex(req.getParameter("sex"));
			int i = userDao.register(user);//���ڼ�¼�Ƿ�ע��ɹ�
			if(i == 1){
				req.getRequestDispatcher("login.jsp").forward(req, resp);
			} else {
				req.getRequestDispatcher("register.jsp").forward(req, resp);
			}
		}
		
		//��¼
		if("login".equals(method)){
			User user = new User();
			user.setUsername(req.getParameter("username"));
			user.setPassword(req.getParameter("password"));
			boolean i = userDao.login(user);//���ݲ���
			if(i){
				req.getRequestDispatcher("index.jsp").forward(req, resp);
			} else {
				req.getRequestDispatcher("login.jsp").forward(req, resp);
			}
		}
	}
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(req, resp);
	}
}
