package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Book;
import dao.BookDao;

public class insertServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		//获取图书数据
		BookDao bookDao = new BookDao();
		int id = (Integer.parseInt(request.getParameter("id")));
		String novel_name = request.getParameter("novel_name");
		String author_name = request.getParameter("author_name");
		String novel_content = request.getParameter("novel_content");
		String uploaduser = request.getParameter("uploaduser");
		String createdate = request.getParameter("createdate");

		Book b = new Book();
		b.setId(id);
		b.setNovel_name(novel_name);
		b.setAuthor_name(author_name);
		b.setNovel_content(novel_content);
		b.setUploaduser(uploaduser);
		b.setCreatedate(createdate);
		int i = bookDao.addBook(b);
		if (i > 0) {
			out.print("true");
			// 刷新
			List<Book> list = bookDao.getAllBooks();
			request.getSession().setAttribute("list", list);
		} else {
			out.print("false");
		}
		out.flush();
		out.close();
	}
}
