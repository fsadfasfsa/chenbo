package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Book;
import dao.BookDao;

public class idServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}
 
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		int id=Integer.parseInt(request.getParameter("id"));
		BookDao bs=new BookDao();
		Book booksByid = bs.getBooksByid(id);
		request.getSession().setAttribute("book", booksByid);
		response.sendRedirect("Update.jsp");
		//要调用BookDao的方法，根据id值查到修改的Book对象，查到id对应的Book对象后，将该对象绑定到session上，再跳转到updata.jsp页面
		out.flush();
		out.close();
	}
}
