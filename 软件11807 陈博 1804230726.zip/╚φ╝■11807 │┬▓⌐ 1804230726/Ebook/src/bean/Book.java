package bean;

public class Book {
	private int id;
	private String novel_name;
	private String author_name;
	private String novel_content;
	private String uploaduser;
	private String createdate;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNovel_name() {
		return novel_name;
	}
	public void setNovel_name(String novel_name) {
		this.novel_name = novel_name;
	}
	public String getAuthor_name() {
		return author_name;
	}
	public void setAuthor_name(String author_name) {
		this.author_name = author_name;
	}
	public String getNovel_content() {
		return novel_content;
	}
	public void setNovel_content(String novel_content) {
		this.novel_content = novel_content;
	}
	public String getUploaduser() {
		return uploaduser;
	}
	public void setUploaduser(String uploaduser) {
		this.uploaduser = uploaduser;
	}
	public String getCreatedate() {
		return createdate;
	}
	public void setCreatedate(String createdate) {
		this.createdate = createdate;
	}
	public String toString() {
		return "Booking [id=" + id + ", novel_name=" + novel_name + ", author_name=" + author_name + ", novel_content="
				+ novel_content + ", uploaduser=" + uploaduser + ", createdate=" + createdate + "]";
	}
}
