package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//功能bean，实现连接数据库功能
public class DBConnection {

	public static Connection getConn() {

		Connection conn = null;

		try {

			
			Class.forName("com.mysql.jdbc.Driver");// 加载注册数据库驱动
			conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/novel?useUnicode=true&characdterEncoding=utf8",
					"root", "123456");// 获取连接对象，连接数据库

		} catch (ClassNotFoundException e) {

			System.out.println("驱动异常" + e.getMessage());

		} catch (SQLException e2) {

			System.out.println("连接异常" + e2.getMessage());
		}

		return conn;
	}

}
