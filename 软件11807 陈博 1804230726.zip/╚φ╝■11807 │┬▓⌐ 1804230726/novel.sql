/*
 Navicat Premium Data Transfer

 Source Server         : MYSQL
 Source Server Type    : MySQL
 Source Server Version : 50717
 Source Host           : localhost:3306
 Source Schema         : novel

 Target Server Type    : MySQL
 Target Server Version : 50717
 File Encoding         : 65001

 Date: 23/06/2021 08:58:42
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for novel
-- ----------------------------
DROP TABLE IF EXISTS `novel`;
CREATE TABLE `novel`  (
  `id` int(8) NOT NULL COMMENT '图书编号',
  `novel_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '图书名称',
  `author_name` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '图书作者',
  `novel_content` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '图书摘要',
  `uploaduser` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '上传人',
  `createdate` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '上传时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of novel
-- ----------------------------
INSERT INTO `novel` VALUES (1, '我的贴身校花', '带玉', '唐宇，高中毕业，得到一瓶丹药，后来得知自己的身世。竟来自上古唐家。', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (2, '飞起来的是我', '吴纯', '不懂就不要装懂', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (3, '灭神帝尊', '小花丛', '修炼到帝尊以后，从此灭神无数...', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (4, '传奇商人', '打蜜蜂', '商人白手起家，从此创造奇迹...', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (5, '刀神兵王', '大嘴巴', '兵王打造世界工业级帝国，称霸一方，无人可档...', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (6, '惊世王妃', '不知火舞', '她的雪凡心，造就了一代天才，但是没有人知道她来自上古战神世家的三公主...', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (7, '早安，龙先生', '丑八怪', '“给我生个继承人”，什么时候她就进入了他的禁地...', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (8, '报告首长', '百鸟朝凤', '日本已经被赶出中国了，但他死了...', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (9, '重生之冰神帝国', '江山一顾', '死后，一个白点进入他的身体，尸体消失了，', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (10, '绝世神医', '寒笑烟', '得到了医圣的传承后，一举成名，后来踏上了寻找医圣的骸骨成为尊神医圣...', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (11, '贴身校花', '带玉', '唐宇，高中毕业，得到一瓶丹药，后来得知自己的身世。竟来自上古唐家。', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (12, '猎者天下', '那时烟花', '世界上最幸福的事，就是做错了，有后悔的机会。', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (13, '老九门', '南派三叔', '长沙九大家族，称为老九门。', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (14, '44号棺材铺', '凌晨0点', '朔月有个牛逼的职业，叫做“收尸的”。', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (15, '沙海', '南派三叔', '高中生黎簇，无意间被卷入老九门。', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (16, '疾风剑豪', '英雄', '疾风剑豪。', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (17, '战争女神', '英雄', '呜呜呜呜呜', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (19, '战争之影', '英雄', '攻击力最高', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (20, '战争之王', '英雄', '大招远距离', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (21, '奇妙幻想', '英雄', '呜呜呜呜呜', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (22, '我知道的', '随风', '我知道的', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (23, '战争之王', '随风', '我知道的', '向云飞', '2021-06-21');
INSERT INTO `novel` VALUES (24, '无敌无敌', '李四', '呜呜呜呜呜', '向云飞', '2021-06-21');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `email` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sex` varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (13, 'qq', 'qq', '12345678', 'male');
INSERT INTO `user` VALUES (14, 'mike', '123456', '111@qq.com', '男');
INSERT INTO `user` VALUES (15, 'rose', '123456', '222@qq.com', '男');
INSERT INTO `user` VALUES (16, 'hq', 'hq', 'hq@qq.com', '男');
INSERT INTO `user` VALUES (17, '张三', '1234', '11@qq.com', '男');
INSERT INTO `user` VALUES (18, '向云飞', '123', '1759427222@qq.com', '男');

SET FOREIGN_KEY_CHECKS = 1;
